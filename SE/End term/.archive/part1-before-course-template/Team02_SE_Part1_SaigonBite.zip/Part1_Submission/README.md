# SaigonBite — Part 1 submission set

Deadline: 07:00 Monday 26 October 2026 (UTC+7).

- `Team02_SE_Final_Report_SaigonBite.pdf`: report, 38 pages; includes proposal, requirements, NFRs, ambiguity log, RTM and AI disclosure.
- `Presentation1_Solution_Pitch.pdf`: dependable five-slide projection copy.
- `Presentation1_Solution_Pitch.pptx`: editable PowerPoint deck with Vietnamese speaker notes.
- `Team02_SE_Team_Workbook_SaigonBite.xlsx`: four tracking sheets aligned with the report.
- `Presentation1_SpeakerNotes_VI.md`: separate rehearsal script, planned 6:15 for three speakers.

Upload the report and slide format accepted by the portal; update/provide the workbook as instructed. This folder contains no source/build caches. The zip is a convenience copy, not proof the portal accepts zip submission.

Instructor: ThS. Phạm Thái Kỳ Trung (degree corrected by the student). Target: Tier4 proposed, ceiling10.0; Core MVC/EF Core variant pending instructor confirmation. Live sandbox API, interactive Admin dashboard and automated tests are planned obligations, not certified by this Part1 set.

Before upload: confirm Team02 and report date; rehearse with all three members. The course-specific report DOCX was not available for exact template comparison. Earlier DSH full prompts/outputs still need recovery; their absence is disclosed, not hidden. No signature or instructor approval has been generated.
