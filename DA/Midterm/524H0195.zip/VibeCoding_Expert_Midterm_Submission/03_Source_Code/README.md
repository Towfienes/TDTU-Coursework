# Source code — VibeCoding_Expert midterm

| Path | Content |
|---|---|
| `notebooks/VibeCoding_Expert_Midterm.ipynb` | Full analysis (data loading, quality checks, cleaning, descriptive, diagnostic, predictive, prescriptive, export), executed with outputs |
| `notebooks/VibeCoding_Expert_Midterm.html` | Read-only copy of the executed notebook |
| `dashboard/app.py` | Streamlit dashboard |
| `data/processed/` | `fnb_scored.parquet` (84,632 scored F&B tweets) and `daily_negative_share.csv` |
| `artifacts/` | `model_lr.joblib`, `model_nb.joblib`, `key_numbers.json`, `metrics.json` and the result tables (CSV) |
| `figures/` | All report figures (PNG, 200 dpi) |
| `validation/` | 210-tweet review sample of the F&B dictionary (AI-assisted, single reviewer) |
| `archive/` | Place for the raw Kaggle CSV (not included, 239 MB) |
| `.streamlit/config.toml` | Dashboard theme |

## Setup

```
pip install -r requirements.txt
```

## Dashboard

```
python -m streamlit run dashboard/app.py
```

Open http://localhost:8501. Add `?tab=Try+the+model` (or `?tab=Aspects`, `?tab=Brands`) to the address to open a tab directly.
Use `python -m streamlit` so that the Python with the installed libraries runs the app.

## Notebook

1. Download `training.1600000.processed.noemoticon.csv` from https://www.kaggle.com/datasets/kazanova/sentiment140 into `archive/`.
2. Open `notebooks/VibeCoding_Expert_Midterm.ipynb` and choose *Run All* (about 6-10 minutes with 16 GB RAM),
   or run `jupyter nbconvert --to notebook --execute --inplace notebooks/VibeCoding_Expert_Midterm.ipynb`.
3. Set `FAST_MODE = True` in the setup cell for a quick test on a 10% sample (numbers will then differ slightly).

The notebook uses a fixed random seed (42) and relative paths, so the results are reproducible on any machine.
