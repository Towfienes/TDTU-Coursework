# Midterm Project — Data Analysis and Visualization

**Topic:** Social-media sentiment analysis for a new F&B product launch
**Dataset:** Sentiment140, 1.6 million tweets (https://www.kaggle.com/datasets/kazanova/sentiment140)
**Lecturer:** Ho Thi Linh, Ph.D. · Ton Duc Thang University · Presentation: 16 October 2026

**Group VibeCoding_Expert**

| Member | Student ID | Role |
|---|---|---|
| Ngo Lam Tien | 524H0195 | Leader |
| Nguyen Cong Thanh | 524H0191 | Member |
| Nguyen Le Nhat Tam | 524H0186 | Member |
| Ngo Binh Minh | 524H0169 | Member |

## Contents

| Folder | Files | Required product |
|---|---|---|
| `01_Report/` | `VibeCoding_Expert_Midterm_Report.docx` (+ `.pdf`) | Word report: Introduction, Data, Descriptive, Diagnostic, Predictive, Prescriptive, Conclusion, Task allocation, References |
| `02_Slides/` | `VibeCoding_Expert_Midterm_Slides.pptx` (+ `.pdf`) | Presentation slides (16 slides + 3 appendix slides, speaker notes included) |
| `03_Source_Code/` | `notebooks/VibeCoding_Expert_Midterm.ipynb` (+ `.html`), `dashboard/app.py`, data, models, figures | Runnable notebook with step-by-step comments, and the interactive dashboard |
| `04_Dashboard_Preview/` | 3 screenshots | Preview of the Streamlit dashboard without running it |

The `.html` copy of the notebook shows every cell, comment and output and opens in any web browser.

## How to run

From the `03_Source_Code/` folder, with Python 3.12:

```
pip install -r requirements.txt
python -m streamlit run dashboard/app.py
```

The dashboard opens at http://localhost:8501. It runs on the processed data and fitted model included in the
package, so the raw dataset is not needed.

To re-run the full analysis, download `training.1600000.processed.noemoticon.csv` from Kaggle into
`03_Source_Code/archive/` (239 MB, not included because of its size), then open the notebook and choose *Run All*
(about 6-10 minutes with 16 GB RAM). Every number in the report and slides is regenerated in
`artifacts/key_numbers.json`.

## Where each technical requirement is met

| Requirement | Where |
|---|---|
| At least 6 different chart types, each with title, axis labels, legend and commentary | 13 chart types in the report (stacked column, funnel, donut, Pareto, histogram, line with CI band, horizontal bar, dot plot with error bars, heatmap, diverging bar, grouped column, ROC curve, waterfall, bubble); commentary under every figure |
| Predictive model: baseline vs more advanced algorithm | Multinomial Naive Bayes vs Logistic Regression on TF-IDF of words and word pairs (Report 5.3-5.5) |
| Train/test split presented and justified | Time-based split: train 6 Apr-31 May, validation 1-7 Jun, test 14-16 Jun, compared with a random split (Report 2.6, 5.2, 5.6) |
| Model interpretation technique | Logistic Regression coefficients, term-level waterfall explanations, odds ratios of a logistic regression (Report 4.4, 5.7) |
| Prescriptive recommendations cite figures from the three previous layers | Table 6.1: each recommendation quotes descriptive, diagnostic and predictive evidence |
| Interactive dashboard | Streamlit app in `03_Source_Code/dashboard/` (filters, KPI tiles, five tabs, live model scoring) |
